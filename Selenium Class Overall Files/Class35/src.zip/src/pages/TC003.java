package pages;
import com.alphabet.gmail.webdrivermethods.BasicSettings;
//Verify Invalid Login(Assignment)
public class TC003 extends BasicSettings
{	
	public static void main(String[] args) 
	{
		
	}
}
