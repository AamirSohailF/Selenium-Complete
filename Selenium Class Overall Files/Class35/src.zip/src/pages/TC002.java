package pages;
import com.alphabet.gmail.webdrivermethods.BasicSettings;
// Search for a task in the home Page (Assignment)
public class TC002 extends BasicSettings 
{
	
}
