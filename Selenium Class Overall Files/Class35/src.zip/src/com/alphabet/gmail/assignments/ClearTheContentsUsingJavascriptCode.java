package com.alphabet.gmail.assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.alphabet.gmail.webdrivermethods.BasicSettings;

public class ClearTheContentsUsingJavascriptCode extends BasicSettings 
{
	public static void main(String[] args) 
	{
		WebDriver driver = setUp("https://demo.vtiger.com/vtigercrm/");
		WebElement username=driver.findElement(By.id("username"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].value='';", username);
	}
}	
