package com.alphabet.gmail.assignments;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.alphabet.gmail.webdrivermethods.BasicSettings;

public class MoveToElementInISTQBSite extends BasicSettings
{
	public static void main(String[] args) throws IOException 
	{
		WebDriver driver = setUp("https://www.istqb.org/");
		WebElement certification = driver.findElement(By.linkText("Certification"));
		
		Actions actions = new Actions(driver);
		actions.moveToElement(certification).perform();
		
		
		String expertXpath = "//li[@class='dropdown-submenu mega']/a[.='Expert Level ']";
		driver.findElement(By.xpath(expertXpath)).click();
	}
}
