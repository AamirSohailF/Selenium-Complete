package com.alphabet.gmail.assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.alphabet.gmail.webdrivermethods.BasicSettings;

public class ActitimeIndustriesElementClickAction extends BasicSettings
{
	public static void main(String[] args) 
	{
		WebDriver driver = setUp("https://www.actitime.com/");
		WebElement featuresLink = driver.findElement(By.xpath("//li[.='Industries']"));
		
		Actions actions = new Actions(driver);
		actions.click(featuresLink).perform();
	}
}
