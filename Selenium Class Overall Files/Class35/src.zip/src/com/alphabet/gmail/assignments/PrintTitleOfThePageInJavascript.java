package com.alphabet.gmail.assignments;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.alphabet.gmail.webdrivermethods.BasicSettings;

public class PrintTitleOfThePageInJavascript extends BasicSettings
{
	public static void main(String[] args) 
	{
		WebDriver driver = setUp("https://www.google.com/");
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("console.log(document.title);");
		js.executeScript("console.log(document.URL);");
	}
}
