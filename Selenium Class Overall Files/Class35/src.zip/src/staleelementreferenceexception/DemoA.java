package staleelementreferenceexception;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DemoA
{
	@FindBy(id="username")
	private WebElement username;
	
	@FindBy(name="pwd")
	private WebElement password;
	
	@FindBy(id="loginButton")
	private WebElement loginButton;
	
	@FindBy(tagName="a")
	private List<WebElement> allLinks;
	
	public void setUsername(String un)
	{
		username.sendKeys(un);
	}
	
	public void setPassword(String passd)
	{
		password.sendKeys(passd);
	}
	
	public void clickLogin()
	{
		loginButton.click();
	}
	
	public int linksCount()
	{
		return allLinks.size();
	}
}
